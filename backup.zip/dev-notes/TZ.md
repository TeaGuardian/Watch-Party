Вот итоговое, консолидированное **Техническое Задание (ТЗ)** для разработки сервиса совместного просмотра. В нем учтены все твои требования, архитектурные решения из обсуждения и лучшие практики из предоставленных тобой примеров кода (`logserver`, `BBS`).

---

# Техническое Задание: Сервис совместного просмотра

## 1. Стек технологий

### Core & Backend
*   **Язык:** Python 3.10+.
*   **Web-фреймворк:** **Flask** (синхронный). Используется для API, рендеринга страниц и администрирования.
*   **WebSocket:** **Flask-SocketIO**. Обеспечивает синхронизацию плеера, чат и обновление статусов в реальном времени.
*   **Telegram Bot:** **aiogram 3.x** (асинхронный). Запускается в отдельном потоке (Dev) или процессе (Prod).
*   **Task Queue:** **Redis** + **Celery**. Для тяжелых задач (конвертация видео, каскадное удаление файлов).

### Database & Storage
*   **ORM:** **Peewee**.
*   **DB Driver:**
    *   *Dev:* SQLite.
    *   *Prod:* PostgreSQL.
*   **Storage System:** Паттерн "Стратегия" (`StorageManager`).
    *   *Dev:* Локальная файловая система (`LocalStorage`).
    *   *Prod:* **MinIO** (S3-compatible) через библиотеку `boto3` или `minio` (`S3Storage`).

### Frontend & Media
*   **Templating:** **Jinja2** (Server-side rendering базовой структуры).
*   **Logic:** Vanilla JS (ES6+) + Fetch API (для динамической подгрузки данных без перезагрузки).
*   **Player:** **hls.js** + HTML5 Video Tag.
*   **Video Processing:** **FFmpeg** (конвертация исходников в HLS `.m3u8` + `.ts`).

---

## 2. Функциональные требования

### 2.1. Конфигурация
Используем классовую структуру (как в `BBS`), данные подтягиваем из `.env`.
*   `AppConfig`: Секретные ключи, настройки сессий.
*   `DBConfig`: Выбор типа БД и параметры подключения.
*   `BotConfig`: Токен, ID админов.
*   `StorageConfig`: Endpoint MinIO, ключи доступа.

### 2.2. Система ролей
1.  **Guest (Гость):** Не авторизован. Доступ только к странице входа.
2.  **User (Пользователь):**
    *   *New:* Только зарегистрировался.
    *   *TgVerified:* Привязал ТГ.
    *   *Approved:* Одобрен (полный доступ к комнатам).
    *   *Banned:* Блокировка доступа.
3.  **Moderator (Модератор):** Назначается Админом. Может одобрять/банить пользователей. Не может снимать Админов/Модераторов.
4.  **Admin (Администратор):** Полный доступ, управление персоналом, постинг новостей.

### 2.3. Авторизация и Профиль
*   **Регистрация:** Логин, Пароль. **Обязательный чекбокс** "Согласие на Cookies".
*   **Привязка Telegram:**
    *   Генерация кода в профиле -> Ссылка `t.me/bot?start=CODE`.
    *   Бот отправляет уведомление Админам/Модераторам в ТГ с кнопками [✅ Одобрить] / [⛔ Отклонить] (Inline Keyboards).
*   **Удаление аккаунта:**
    *   Кнопка в профиле (доступна, если не забанен).
    *   **Hard Delete:** Полное удаление записи из БД + Каскадное удаление всех комнат пользователя + Физическое удаление файлов видео из хранилища (S3/Local). Задача выполняется через Celery.

### 2.4. Главная страница (SPA-like навигация)
Верхнее меню переключает контент через JS (скрытие/показ блоков или подгрузка HTML):
1.  **Новости:** Лента постов (Markdown) от Админа.
2.  **Комнаты:** Плитки комнат (Цветная шапка, Название, Онлайн, Текущее медиа).
3.  **Профиль:** Аватар, Статус, Кнопка удаления, Настройки.

### 2.5. Комнаты
*   **Создание:** Название, выбор цвета шапки, тип (Открытая/Закрытая).
*   **Доступ:**
    *   *Открытая:* Заходят все `Approved` пользователи.
    *   *Закрытая:* Заявка на вход -> Владелец видит в реал-тайме -> Одобряет.
*   **Управление (Shared Control):**
    *   В настройках *закрытой* комнаты галочка "Разрешить управление зрителям".
    *   Если включено: любой зритель может ставить паузу, перематывать, менять видео.
*   **Плеер:**
    *   HLS воспроизведение.
    *   Индикаторы рассинхрона под плеером (Серый=Пауза, Зеленый=ОК, Желтый=Отставание, Красный=Сильное отставание).
    *   Глобальная синхронизация: сервер хранит "эталонное" время.

### 2.6. Работа с видео (Background Processing)
1.  **Загрузка:** Юзер грузит файл. Сервер кладет его во временную папку.
2.  **Очередь:** Задача `convert_video_task` летит в Celery.
3.  **Воркер:**
    *   FFmpeg конвертирует видео в `.m3u8`.
    *   `StorageManager` загружает файлы в MinIO (или папку `storage`).
    *   Удаляются временные файлы.
    *   Обновляется статус в БД -> Сокет сообщает комнате "Видео готово".

---

## 3. Структура Базы Данных (Peewee Models)

```python
# models.py

class BaseModel(Model):
    class Meta:
        database = db # Proxy, инициализируется в зависимости от конфига

class User(BaseModel):
    username = CharField(unique=True)
    password_hash = CharField()
    role = CharField(default='user') # user, moderator, admin
    status = CharField(default='new') # new, tg_verified, approved, banned
    
    tg_id = BigIntegerField(null=True)
    tg_username = CharField(null=True)
    verification_code = CharField(null=True) # Код для /start
    
    approved_by = ForeignKeyField('self', null=True) # Кто нажал кнопку в ТГ
    cookie_consent = BooleanField(default=True)
    created_at = DateTimeField(default=datetime.now)

class Room(BaseModel):
    uuid = UUIDField(unique=True)
    owner = ForeignKeyField(User, backref='rooms', on_delete='CASCADE') 
    # on_delete='CASCADE' в БД удалит комнату, но файлы надо чистить вручную кодом!
    
    name = CharField()
    header_color = CharField(default='#000000')
    is_private = BooleanField(default=False)
    allow_guest_control = BooleanField(default=False) # Только для is_private=True
    created_at = DateTimeField(default=datetime.now)

class Video(BaseModel):
    room = ForeignKeyField(Room, backref='videos', on_delete='CASCADE')
    title = CharField()
    
    # Путь в хранилище (bucket/room_uuid/video_uuid/)
    storage_path = CharField() 
    
    status = CharField(default='uploading') # uploading, processing, ready, error
    duration = IntegerField(default=0)
    created_at = DateTimeField(default=datetime.now)

class NewsPost(BaseModel):
    author = ForeignKeyField(User)
    content = TextField() # Markdown
    created_at = DateTimeField(default=datetime.now)
```

---

## 4. Структура проекта

Мы разделяем логику на модули (`core`), веб-часть (`app`), бота (`bot`) и задачи (`worker`), чтобы код не превратился в спагетти.

```text
/project_root
├── main.py                 # Точка входа: запускает Flask и Thread с Ботом (для Dev)
├── celery_worker.py        # Точка входа для Celery (background tasks)
├── config.py               # Классы AppConfig, BotConfig, DBConfig
├── .env                    # Секреты и настройки
├── requirements.txt
│
├── core/                   # Ядро: общие модули
│   ├── __init__.py
│   ├── database.py         # Инициализация db (sqlite/postgres)
│   ├── models.py           # Peewee модели
│   └── storage.py          # StorageManager (Local & MinIO implementation)
│
├── app/                    # Web-приложение
│   ├── __init__.py         # create_app()
│   ├── routes.py           # HTTP endpoints (Login, Upload, Pages)
│   ├── sockets.py          # WebSocket events (Sync, Chat, Status)
│   └── decorators.py       # @check_auth, @admin_required
│
├── bot/                    # Telegram Bot
│   ├── __init__.py
│   ├── loader.py           # Инициализация Bot, Dispatcher
│   └── handlers.py         # Обработка /start и Callback кнопок админки
│
├── tasks/                  # Фоновые задачи
│   ├── __init__.py
│   ├── celery_app.py       # Настройка Celery
│   └── media_tasks.py      # Логика FFmpeg и Cleanup файлов
│
├── templates/              # Jinja2
│   ├── base.html
│   ├── index.html          # Главная (включает табы)
│   ├── room.html           # Плеер + Чат
│   ├── login.html
│   └── admin.html
│
├── static/
│   ├── css/                # Стили
│   ├── js/                 # Скрипты (socket.io logic, player sync)
│   └── vendor/             # hls.js
│
└── storage/                # Папка для LocalStorage (игнорируется git)
    ├── uploads/            # Временные файлы
    └── saved_files/        # Обработанные (если режим Local)
```

### План действий (с чего начнем):
1.  Создание структуры папок и `config.py`.
2.  Реализация `core/storage.py` (менеджеры файлов, как в `logserver`).
3.  Настройка БД (`core/database.py`, `core/models.py`).
4.  Базовый Flask (`main.py`, `app/routes.py`) + Регистрация.
5.  Подключение Бота (`bot/`) для подтверждения регистрации.

Можно приступать к коду!