Вот обновленный `ROADMAP.md`. Это полная техническая карта проекта версии 2.1, описывающая архитектуру, файловую структуру и взаимодействие сервисов. Используйте этот документ как основной гайд для команды разработки и DevOps.

---

# ARCHITECTURE & DEVELOPER GUIDE (v2.1 Docker Edition)

**Project:** Watch Party Service
**Version:** 1.0.0-beta (v2.1 Architecture)
**Date:** 03.12.2025

Этот документ описывает устройство, архитектурные решения, файловую структуру и инструкцию по развертыванию проекта.

---

## 1. Архитектура сервисов (Docker Compose)

Проект разбит на независимые микросервисы, работающие в единой сети Docker.

### 🐳 Контейнеры и их роли

1.  **Nginx (`nginx`)**:
    *   **Роль:** Reverse Proxy, SSL termination (в будущем), раздача статики.
    *   **Важно:** Проксирует заголовки `Upgrade` для работы WebSocket (`/socket.io`).
    *   **Порты:** 80 -> 8000 (Web), 9000 (MinIO).

2.  **Web App (`web`)**:
    *   **Стек:** Python 3.10, Flask, Flask-SocketIO, Gunicorn.
    *   **Воркер:** `eventlet` (Асинхронный).
    *   **Особенность:** Использует `eventlet.monkey_patch()` при старте для совместимости с БД.
    *   **БД:** Использует пул соединений `PooledPostgresqlDatabase`.

3.  **Celery Worker (`celery_worker`)**:
    *   **Роль:** Исполнитель тяжелых задач (FFmpeg транскодинг, удаление файлов).
    *   **Стек:** Celery, FFmpeg.
    *   **Доступ:** Имеет общий том `temp_uploads` с веб-сервером для доступа к "сырым" загрузкам.

4.  **Celery Beat (`celery_beat`)**:
    *   **Роль:** Планировщик периодических задач (Cron).
    *   **Задачи:** Запускает `cleanup_old_videos` каждые 10 минут.

5.  **Telegram Bot (`bot`)**:
    *   **Стек:** Aiogram (AsyncIO).
    *   **Роль:** Верификация пользователей, привязка аккаунтов. Запущен отдельным процессом, чтобы не конфликтовать с Eventlet в Web-контейнере.

6.  **Storage Layer**:
    *   **Postgres (`postgres`):** Основная реляционная БД.
    *   **Redis (`redis`):** Брокер сообщений для Celery и Pub/Sub для Socket.IO.
    *   **MinIO (`minio`):** S3-совместимое хранилище медиа-файлов и аватарок.
    *   **CreateBuckets (`createbuckets`):** Эфемерный контейнер, настраивает бакеты и полиси MinIO при старте.

---

## 2. Файловая структура проекта

Актуальное дерево файлов для сборки и разработки.

```text
/watch_party
├── .env                       # Конфигурация и секреты
├── docker-compose.yml         # Оркестрация сервисов
├── Dockerfile                 # Единый образ для Web, Celery и Bot (Python + FFmpeg)
├── requirements.txt           # Зависимости Python
│
├── main.py                    # Точка входа Gunicorn (Web App + Eventlet Patch)
├── run_bot.py                 # Точка входа Telegram Bot
├── celery_worker.py           # Точка входа Celery (обертка)
│
├── config.py                  # Глобальная конфигурация (читает .env)
│
├── startup_scripts/           # Скрипты инициализации инфраструктуры
│   ├── nginx.conf             # Конфиг Nginx (proxy_pass, limits)
│   └── minio_startup.sh       # Настройка бакетов MinIO
│
├── app/                       # Веб-приложение (Flask)
│   ├── __init__.py            # Фабрика приложения, роуты страниц
│   ├── routes.py              # API Endpoints (Upload, Auth, Rooms)
│   ├── sockets.py             # Логика WebSocket (Sync, Chat, Status)
│   └── decorators.py          # @login_required, @admin_required
│
├── core/                      # Ядро (Общее для Web, Bot и Celery)
│   ├── database.py            # Инициализация БД (PooledDatabase)
│   ├── models.py              # ORM Модели (User, Room, Video)
│   ├── storage.py             # Абстракция S3 (MinIO) / Local
│   └── validators.py          # Проверка паролей и данных
│
├── tasks/                     # Фоновые задачи
│   ├── celery_app.py          # Настройка Celery + Beat Schedule
│   └── media.py               # Логика FFmpeg и безопасного удаления
│
├── templates/                 # HTML Шаблоны (SSR)
│   ├── base.html              # Базовый шаблон + Anti-flicker script
│   ├── index.html             # Дашборд
│   ├── login.html             # Вход/Регистрация
│   ├── room.html              # Комната просмотра
│   ├── admin.html             # Админка
│   └── policy.html            # Страница политики и лимитов
│
├── static/                    # Статика
│   ├── css/
│   │   ├── style.css          # Глобальные стили + Темы
│   │   ├── room.css           # Стили плеера и чата
│   │   ├── dashboard.css      # Стили дашборда
│   │   └── admin.css          # Стили админки
│   └── js/
│       ├── main.js            # Общие скрипты (тема, уведомления)
│       ├── room.js            # Логика плеера, сокетов, HLS
│       ├── dashboard.js       # Логика вкладок и профиля
│       └── admin.js           # Логика админ-панели
│
└── storage/                   # Mapped Volumes (Игнорируется git, кроме keep)
    └── uploads/               # Общая папка для "сырых" загрузок (Web -> Celery)
```

---

## 3. Ключевые механизмы реализации

### 3.1. Хранение данных и Дедупликация (CAS)
*   **Принцип:** Content-Addressable Storage. Файлы хранятся по пути `shared_content/{SHA256_HASH}/`.
*   **Загрузка:** При загрузке вычисляется хеш. Если хеш существует в БД (`status='ready'`), новый файл не создается, запись в БД ссылается на существующий путь.
*   **Удаление:** Используется принцип `Reference Counting` (подсчет ссылок). Физические файлы удаляются из S3 только тогда, когда в БД не остается ни одной записи `Video`, ссылающейся на этот хеш.

### 3.2. Безопасность данных (Defense in Depth)
*   **Celery Safe Delete:** Задачи `delete_storage_folder` перед выполнением `rm` делают запрос в БД: "Действительно ли этот путь никем не используется?". Это защита от Race Condition.
*   **MinIO Client:** Используется поштучное удаление объектов (`remove_object` в цикле) вместо массового, чтобы избежать ошибок совместимости XML (`toxml error`).

### 3.3. Стабильность соединений
*   **Eventlet Monkey Patch:** Вызывается в первой строке `main.py`. Обязательно для корректной работы `gunicorn + socketio`.
*   **DB Pooling:** Используется `playhouse.pool.PooledPostgresqlDatabase`. Каждое событие сокета обернуто в декоратор `@db_session`, который берет соединение из пула и возвращает его обратно.
*   **Socket ID:** Идентификация зрителей в комнате происходит по `request.sid`, что позволяет корректно отображать одного пользователя с разных вкладок/устройств.

---

## 4. Развертывание (Deployment)

### Требования
*   Docker Engine v20+
*   Docker Compose v2+

### Запуск
1.  Создать `.env` файл на основе примера.
2.  Собрать и запустить:
    ```bash
    docker compose up -d --build
    ```

### Обновление кода
Если меняется код (Python/JS/HTML), требуется пересборка:
```bash
docker compose up -d --build
```

### Полный сброс (Hard Reset)
Если нужно очистить БД и S3 (например, при ошибках миграции):
```bash
docker compose down -v
docker compose up -d --build
```
*(Флаг `-v` удаляет тома `postgres_data` и `minio_data`)*.

---

## 5. Переменные окружения (.env)

Для корректной работы требуются следующие переменные:

| Группа | Переменная | Значение по умолчанию | Описание |
| :--- | :--- | :--- | :--- |
| **App** | `SECRET_KEY` | *changeme* | Ключ Flask сессий |
| | `MAX_ROOM_STORAGE_MB` | 3072 | Лимит 3ГБ на комнату |
| | `MAX_VIDEO_SIZE_MB` | 500 | Лимит на 1 файл |
| **DB** | `POSTGRES_USER` | postgres | |
| | `POSTGRES_PASSWORD` | password | |
| | `POSTGRES_HOST` | postgres | Имя хоста контейнера |
| **MinIO** | `S3_ENDPOINT` | 212.x.x.x:9000 | **Внешний IP** сервера |
| | `S3_ACCESS_KEY` | minioadmin | |
| | `S3_SECRET_KEY` | minioadmin | |
| **Bot** | `BOT_TOKEN` | *token* | От @BotFather |
| **Redis** | `REDIS_HOST` | redis | Имя хоста контейнера |

---

## 6. Known Issues & Workarounds

1.  **Ошибка `Bad file descriptor` в логах:**
    *   *Причина:* Конфликт потоков Eventlet и Psycopg2.
    *   *Решение:* Применено. Используется `PooledPostgresqlDatabase` и декоратор `@db_session`.
2.  **Ошибка S3 `toxml` при удалении:**
    *   *Причина:* Баг в библиотеке `minio` при сериализации объектов `DeleteObject`.
    *   *Решение:* Применено. В `core/storage.py` используется цикл с поштучным удалением.
3.  **CORS ошибки Socket.IO:**
    *   В `__init__.py` прописано `cors_allowed_origins="*"`. В продакшене рекомендуется сузить до домена.