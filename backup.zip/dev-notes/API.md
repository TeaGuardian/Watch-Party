Вот обновленный файл **API.md**. Он включает новые эндпоинты (переименование), новые коды ошибок (лимиты хранилища, дубликаты), обновленные структуры данных WebSocket (идентификация по `sid`) и логику дедупликации.

---

# API DOCUMENTATION (v2.1)

Документация описывает REST API и WebSocket события проекта **Watch Party**.

## 1. Общие сведения

*   **Base URL:** `http://your-domain.com`
*   **Протокол:** HTTP/1.1 (HTTPS рекомендуется через Nginx).
*   **Аутентификация:** Session Cookies (`session`). Устанавливаются автоматически после успешного входа или регистрации.
*   **Формат данных:** JSON.
*   **Обработка ошибок:** В случае ошибки возвращается HTTP 4xx/5xx и JSON тело.

### Структура ответа
**Успешный запрос (200 OK):**
```json
{
  "success": true,
  "data": "...",
  "message": "Optional text"
}
```

**Ошибка (4xx, 5xx):**
```json
{
  "error": "Human readable message",
  "code": "ERROR_CODE"
}
```

**Коды ошибок (`code`):**
*   `auth_required` — Не авторизован.
*   `banned` — Аккаунт или доступ к комнате заблокирован.
*   `limit_reached` — Превышен лимит количества (комнат или видео).
*   `file_too_large` — Файл превышает лимит размера.
*   `storage_limit_reached` — Превышен лимит общего объема хранилища (3 ГБ).
*   `duplicate_video` — Видео с таким содержимым уже есть в текущей комнате.

---

## 2. Аутентификация

### Получить капчу
`GET /api/captcha`
*   Возвращает изображение PNG. Код сохраняется в сессии.

### Регистрация
`POST /api/register`
*   **Body:**
    ```json
    {
      "username": "user1",
      "password": "Password1!",
      "cookie_consent": true,
      "captcha": "WXYZ"
    }
    ```

### Вход
`POST /api/login`
*   **Body:** `{"username": "...", "password": "...", "captcha": "..."}`

### Выход
`POST /api/logout`
*   Очищает сессию.

---

## 3. Профиль пользователя

### Получить текущего пользователя
`GET /api/me`
*   **Response:**
    ```json
    {
      "id": 1,
      "username": "user1",
      "role": "user",
      "status": "approved",
      "tg_connected": true,
      "tg_username": "tg_login",
      "avatar_url": "/content/users/1/avatar.jpg",
      "approved_by": "admin_name"
    }
    ```

### Telegram
*   `GET /api/tg_link` — Получить ссылку для бота (`t.me/bot?start=CODE`).
*   `DELETE /api/tg_link` — Отвязать Telegram (сбрасывает статус аккаунта на `new`).

### Аватар
*   `POST /api/profile/avatar` — `multipart/form-data`, поле `avatar`.
*   `DELETE /api/profile/avatar` — Удалить аватар.

### Удаление аккаунта
`DELETE /api/account`
*   Полное удаление пользователя.
*   Запускает фоновую задачу на очистку личных файлов и проверку "осиротевших" общих файлов.

---

## 4. Комнаты (Rooms)

### Получить список
`GET /api/rooms`
*   Возвращает список своих и гостевых комнат.
*   Поля: `online_count`, `now_playing` (название видео), `is_owner`.

### Создать комнату
`POST /api/rooms`
*   **Body:**
    ```json
    {
      "name": "Кинозал",
      "header_color": "#0d6efd",
      "is_private": true,
      "allow_guest_control": false
    }
    ```
*   **Error:** `limit_reached` (если > 10 комнат).

### Данные комнаты (Вход)
`GET /api/rooms/<uuid>`
*   Возвращает детальную информацию и плейлист.
*   **Response:**
    ```json
    {
      "room": { "uuid": "...", "name": "...", "owner_name": "...", ... },
      "videos": [
        {
          "id": 10,
          "title": "Movie.mp4",
          "status": "ready", // uploading, processing, ready, error
          "duration": 1200,
          "size_mb": 450.5,
          "url": "/content/shared_content/HASH/index.m3u8"
        }
      ],
      "is_owner": true,
      "has_access": true
    }
    ```

### Настройки комнаты
*   `PUT /api/rooms/<uuid>` — Обновить настройки (Body аналогичен созданию).
*   `DELETE /api/rooms/<uuid>` — Удалить комнату (Владелец).
*   `DELETE /api/rooms/<uuid>/leave` — Покинуть чужую комнату (Гость).

### Бан-лист (Владелец)
*   `GET /api/rooms/<uuid>/bans` — Список забаненных.
*   `POST /api/rooms/<uuid>/bans` — `{ "user_id": 1 }`.
*   `DELETE /api/rooms/<uuid>/bans/<id>` — Разбанить.

---

## 5. Медиа-контент (Видео)

### Загрузить видео
`POST /api/rooms/<uuid>/upload`
*   **Content-Type:** `multipart/form-data`
*   **Body:** файл в поле `video`.
*   **Логика:**
    1.  Проверка квоты файлов в комнате (`limit_reached`).
    2.  Проверка размера файла (`file_too_large`).
    3.  Проверка общего веса комнаты 3ГБ (`storage_limit_reached`).
    4.  Проверка хеша:
        *   Если видео с таким хешем есть в *этой* комнате -> Ошибка `duplicate_video`.
        *   Если видео есть в *другой* комнате -> **Мгновенное добавление** (Дедупликация).
        *   Если видео новое -> Загрузка и транскодинг.

### Переименовать видео
`PUT /api/videos/<id>`
*   **Body:** `{ "title": "Новое название" }`
*   Изменяет только отображаемое имя.

### Удалить видео
`DELETE /api/videos/<id>`
*   Удаляет запись из плейлиста комнаты.
*   Физическое удаление файлов происходит асинхронно, только если на этот контент (хеш) больше никто не ссылается.

---

## 6. Администрирование

*   `GET /api/admin/stats` — Общая статистика.
*   `GET /api/admin/users` — Таблица пользователей.
*   `POST /api/admin/users/<id>/status` — Изменить статус/роль.
    *   Body: `{ "status": "approved" }` или `{ "role": "moderator" }`.
*   `DELETE /api/admin/users/<id>` — Принудительное удаление.

---

## 7. WebSocket API (Socket.IO)

**Namespace:** `/` (default)

### Исходящие события (Client -> Server)

| Событие | Payload | Описание |
| :--- | :--- | :--- |
| `join` | `{ "room_uuid": "..." }` | Вход в комнату. |
| `leave` | `{ "room_uuid": "..." }` | Выход (закрытие вкладки). |
| `heartbeat` | `{ "room_uuid": "...", "timestamp": 12.5, "state": "playing" }` | Статус (каждые 2 сек). |
| `sync_action` | `{ "room_uuid": "...", "action": "play/pause/seek", "timestamp": 10 }` | Управление плеером. |
| `change_video` | `{ "room_uuid": "...", "video_id": 1 }` | Смена видео (Владелец). |
| `knock_knock` | `{ "room_uuid": "..." }` | Запрос доступа в приватную комнату. |
| `decide_knock` | `{ "room_uuid": "...", "target_user_id": 1, "decision": "approve" }` | Ответ владельца. |

### Входящие события (Server -> Client)

| Событие | Payload | Описание |
| :--- | :--- | :--- |
| `user_joined` | `{ "username": "...", "sid": "Az1...", "avatar": "..." }` | Вошел новый участник (или новая вкладка). |
| `user_left` | `{ "user_id": 1, "sid": "Az1..." }` | Участник вышел. **Важно:** удалять из UI по `sid`. |
| `status_update` | `{ "user_id": 1, "sid": "Az1...", "state": "playing", "timestamp": 10 }` | Данные для "светофора". |
| `sync_event` | `{ "action": "play", "timestamp": 10, "actor": "User" }` | Команда плееру. |
| `load_video` | `{ "url": "...", "title": "...", "video_id": 1 }` | Команда загрузить новое видео. |
| `playlist_refresh` | `{}` | Сигнал обновить список видео (загрузка завершена, переименование). |
| `room_updated` | `{ "name": "...", "header_color": "..." }` | Обновились настройки комнаты. |
| `incoming_knock` | `{ "user_id": 1, "username": "...", "avatar": "..." }` | Владельцу: стук в дверь. |
| `access_granted` | `{ "room_uuid": "..." }` | Гостю: доступ разрешен (нужен релоад). |
| `error_limit` | `{ "msg": "...", "redirect": true }` | Превышен лимит вкладок. |